# Egor Godenov — Portfolio

Interactive portfolio of Egor Godenov, motion and performance designer, styled as a macOS desktop.

- Motion reel: https://beamish-tapioca-c0288c.netlify.app
- Behance: https://www.behance.net/Godenov
- LinkedIn: https://www.linkedin.com/in/godenov/
- Telegram: @bobombob

## Run locally

```bash
pnpm install
pnpm dev
```

Build for production with `pnpm build`; the result is in `dist`.

## Where to edit content

- `src/constants/index.ts` holds almost everything: dock apps, skills, social links, project folders, the About me text and the gallery.
- `public/files/resume.pdf` is the resume shown in the Resume window.
- `public/images/egor.png` is the profile photo.

Project covers in the Gallery and in the project folders are loaded from the Behance CDN. For maximum reliability, download them into `public/images/` and change the paths in `src/constants/index.ts`.

## Credits

Built on the open-source [macos-portfolio](https://github.com/xiaopeng-ye/macos-portfolio) template by Xiaopeng Ye (MIT License).
