import type {
  NavLink,
  NavIcon,
  DockApp,
  TechStackItem,
  Social,
  PhotoLink,
  GalleryItem,
  Location,
  WindowConfig,
} from './types';

export const navLinks: NavLink[] = [
  {
    id: 1,
    name: "Projects",
    type: "finder",
  },
  {
    id: 3,
    name: "Contact",
    type: "contact",
  },
  {
    id: 4,
    name: "Resume",
    type: "resume",
  },
];

export const navIcons: NavIcon[] = [
  {
    id: 1,
    img: "/icons/wifi.svg",
  },
  {
    id: 2,
    img: "/icons/search.svg",
  },
  {
    id: 3,
    img: "/icons/user.svg",
  },
  {
    id: 4,
    img: "/icons/mode.svg",
  },
];

export const dockApps: DockApp[] = [
  {
    id: "finder",
    name: "Portfolio",
    icon: "finder.png",
    canOpen: true,
  },
  {
    id: "safari",
    name: "Motion Reel",
    icon: "safari.png",
    canOpen: true,
  },
  {
    id: "photos",
    name: "Gallery",
    icon: "photos.png",
    canOpen: true,
  },
  {
    id: "contact",
    name: "Contact",
    icon: "contact.png",
    canOpen: true,
  },
  {
    id: "terminal",
    name: "Skills",
    icon: "terminal.png",
    canOpen: true,
  },
  {
    id: "trash",
    name: "Archive",
    icon: "trash.png",
    canOpen: false,
  },
];

export const techStack: TechStackItem[] = [
  {
    category: "Motion & Video",
    items: ["After Effects", "Premiere Pro", "DaVinci Resolve", "CapCut", "Cinema 4D", "Blender"],
  },
  {
    category: "Graphics & UI/UX",
    items: ["Photoshop", "Illustrator", "Figma"],
  },
  {
    category: "AI Production",
    items: ["Midjourney", "Runway", "Kling", "Veo", "Nano Banana", "HeyGen", "ElevenLabs", "Topaz Video AI"],
  },
  {
    category: "Performance",
    items: ["Google UAC", "Facebook Ads", "TikTok Ads", "Keitaro", "Binom", "Spy services"],
  },
  {
    category: "Web & QA",
    items: ["Tilda", "HTML5", "Vibe coding", "Git", "DevTools", "Postman", "Jira"],
  },
  {
    category: "Verticals",
    items: ["iGaming", "Crypto", "Nutra"],
  },
];

export const socials: Social[] = [
  {
    id: 1,
    text: "Telegram",
    icon: "/icons/telegram.svg",
    bg: "#2aabee",
    link: "https://t.me/bobombob",
  },
  {
    id: 2,
    text: "Behance",
    icon: "/icons/behance.svg",
    bg: "#1769ff",
    link: "https://www.behance.net/Godenov",
  },
  {
    id: 3,
    text: "Motion Reel",
    icon: "/icons/atom.svg",
    bg: "#4bcb63",
    link: "https://beamish-tapioca-c0288c.netlify.app",
  },
  {
    id: 4,
    text: "LinkedIn",
    icon: "/icons/linkedin.svg",
    bg: "#05b6f6",
    link: "https://www.linkedin.com/in/godenov/",
  },
];

export const photosLinks: PhotoLink[] = [
  {
    id: 1,
    icon: "/icons/gicon1.svg",
    title: "Library",
  }
];

export const gallery: GalleryItem[] = [
  {
    id: 1,
    img: "https://mir-s3-cdn-cf.behance.net/projects/404/21b171213968219.Y3JvcCwxMzcxLDEwNzIsMCwz.jpg",
  },
  {
    id: 2,
    img: "https://mir-s3-cdn-cf.behance.net/projects/404/8ad684253296837.Y3JvcCwxMzA5LDEwMjQsMCww.jpg",
  },
  {
    id: 3,
    img: "https://mir-s3-cdn-cf.behance.net/projects/404/6e35ff253222183.Y3JvcCw5ODYsNzcxLDcsMA.jpg",
  },
  {
    id: 4,
    img: "https://mir-s3-cdn-cf.behance.net/projects/404/0ccfc4253268009.Y3JvcCwxOTQzLDE1MjAsOSww.png",
  },
  {
    id: 5,
    img: "https://mir-s3-cdn-cf.behance.net/projects/404/3836b8214751357.Y3JvcCwxMzcxLDEwNzIsMCwz.jpg",
  },
  {
    id: 6,
    img: "https://mir-s3-cdn-cf.behance.net/projects/404/2fd8e6211603601.Y3JvcCwxMzgwLDEwODAsMjkwLDA.png",
  },
];

const BEHANCE = "https://www.behance.net/Godenov";

const WORK_LOCATION: Location = {
  id: 1,
  type: "work",
  name: "Work",
  icon: "/icons/work.svg",
  kind: "folder",
  children: [
    {
      id: 5,
      name: "Motion Reel",
      icon: "/images/folder.png",
      kind: "folder",
      position: "top-10 left-5",
      windowPosition: "top-[5vh] left-5",
      children: [
        {
          id: 1,
          name: "Motion Reel.txt",
          icon: "/images/txt.png",
          kind: "file",
          fileType: "txt",
          position: "top-5 left-10",
          description: [
            "Motion creatives for performance campaigns: After Effects, AI-assisted production, lip-sync and voice replacement, adapted for every geo.",
            "Open the reel to see the work in motion.",
          ],
        },
        {
          id: 2,
          name: "motion-reel.app",
          icon: "/images/safari.png",
          kind: "file",
          fileType: "url",
          href: "https://beamish-tapioca-c0288c.netlify.app",
          position: "top-10 right-20",
        },
      ],
    },
    {
      id: 6,
      name: "Casino Ads",
      icon: "/images/folder.png",
      kind: "folder",
      position: "top-52 right-80",
      windowPosition: "top-[22vh] left-5",
      children: [
        {
          id: 1,
          name: "Casino Ads.txt",
          icon: "/images/txt.png",
          kind: "file",
          fileType: "txt",
          position: "top-5 right-10",
          description: [
            "Gambling and casino ad banners: static creatives built for traffic.",
            "More examples from iGaming, crypto and nutra are available on request in Telegram: @bobombob.",
          ],
        },
        {
          id: 2,
          name: "behance.net",
          icon: "/images/safari.png",
          kind: "file",
          fileType: "url",
          href: BEHANCE,
          position: "top-20 left-20",
        },
        {
          id: 4,
          name: "casino-ads.png",
          icon: "/images/image.png",
          kind: "file",
          fileType: "img",
          position: "top-52 left-80",
          imageUrl: "https://mir-s3-cdn-cf.behance.net/projects/404/21b171213968219.Y3JvcCwxMzcxLDEwNzIsMCwz.jpg",
        },
      ],
    },
    {
      id: 7,
      name: "SoftSwiss x SiGMA",
      icon: "/images/folder.png",
      kind: "folder",
      position: "top-10 left-80",
      windowPosition: "top-[39vh] left-5",
      children: [
        {
          id: 1,
          name: "SoftSwiss x SiGMA.txt",
          icon: "/images/txt.png",
          kind: "file",
          fileType: "txt",
          position: "top-5 left-10",
          description: [
            "A concept for SoftSwiss × SiGMA Malta 2027.",
            "The full case is on Behance.",
          ],
        },
        {
          id: 2,
          name: "behance.net",
          icon: "/images/safari.png",
          kind: "file",
          fileType: "url",
          href: BEHANCE,
          position: "top-10 right-20",
        },
        {
          id: 4,
          name: "softswiss-sigma.png",
          icon: "/images/image.png",
          kind: "file",
          fileType: "img",
          position: "top-52 right-80",
          imageUrl: "https://mir-s3-cdn-cf.behance.net/projects/404/8ad684253296837.Y3JvcCwxMzA5LDEwMjQsMCww.jpg",
        },
      ],
    },
    {
      id: 8,
      name: "PLAYRIX Universe",
      icon: "/images/folder.png",
      kind: "folder",
      position: "top-52 left-5",
      windowPosition: "top-[5vh] left-40",
      children: [
        {
          id: 1,
          name: "PLAYRIX Universe.txt",
          icon: "/images/txt.png",
          kind: "file",
          fileType: "txt",
          position: "top-5 left-10",
          description: [
            "PLAYRIX: brand universe and character design system.",
            "The full case is on Behance.",
          ],
        },
        {
          id: 2,
          name: "behance.net",
          icon: "/images/safari.png",
          kind: "file",
          fileType: "url",
          href: BEHANCE,
          position: "top-10 right-20",
        },
        {
          id: 4,
          name: "playrix.png",
          icon: "/images/image.png",
          kind: "file",
          fileType: "img",
          position: "top-52 right-80",
          imageUrl: "https://mir-s3-cdn-cf.behance.net/projects/404/6e35ff253222183.Y3JvcCw5ODYsNzcxLDcsMA.jpg",
        },
      ],
    },
    {
      id: 9,
      name: "MUNDFISH",
      icon: "/images/folder.png",
      kind: "folder",
      position: "top-72 left-80",
      windowPosition: "top-[22vh] left-40",
      children: [
        {
          id: 1,
          name: "MUNDFISH.txt",
          icon: "/images/txt.png",
          kind: "file",
          fileType: "txt",
          position: "top-5 left-10",
          description: [
            "MUNDFISH: AI identity and industrial brand system.",
            "The full case is on Behance.",
          ],
        },
        {
          id: 2,
          name: "behance.net",
          icon: "/images/safari.png",
          kind: "file",
          fileType: "url",
          href: BEHANCE,
          position: "top-10 right-20",
        },
        {
          id: 4,
          name: "mundfish.png",
          icon: "/images/image.png",
          kind: "file",
          fileType: "img",
          position: "top-52 right-80",
          imageUrl: "https://mir-s3-cdn-cf.behance.net/projects/404/0ccfc4253268009.Y3JvcCwxOTQzLDE1MjAsOSww.png",
        },
      ],
    },
    {
      id: 10,
      name: "Collider Photobash",
      icon: "/images/folder.png",
      kind: "folder",
      position: "top-72 right-20",
      windowPosition: "top-[39vh] left-40",
      children: [
        {
          id: 1,
          name: "Collider Photobash.txt",
          icon: "/images/txt.png",
          kind: "file",
          fileType: "txt",
          position: "top-5 left-10",
          description: [
            "Photobash artwork for Team Collider Craftworks.",
            "The full case is on Behance.",
          ],
        },
        {
          id: 2,
          name: "behance.net",
          icon: "/images/safari.png",
          kind: "file",
          fileType: "url",
          href: BEHANCE,
          position: "top-10 right-20",
        },
        {
          id: 4,
          name: "collider-photobash.png",
          icon: "/images/image.png",
          kind: "file",
          fileType: "img",
          position: "top-52 right-80",
          imageUrl: "https://mir-s3-cdn-cf.behance.net/projects/404/3836b8214751357.Y3JvcCwxMzcxLDEwNzIsMCwz.jpg",
        },
      ],
    },
  ],
};

const ABOUT_LOCATION: Location = {
  id: 2,
  type: "about",
  name: "About me",
  icon: "/icons/info.svg",
  kind: "folder",
  children: [
    {
      id: 1,
      name: "me.png",
      icon: "/images/image.png",
      kind: "file",
      fileType: "img",
      position: "top-10 left-5",
      imageUrl: "/images/egor.png",
    },
    {
      id: 4,
      name: "about-me.txt",
      icon: "/images/txt.png",
      kind: "file",
      fileType: "txt",
      position: "top-20 left-72",
      subtitle: "Motion & performance designer",
      image: "/images/egor.png",
      description: [
        "Hey! I'm Egor, a motion and graphic designer who makes ad creatives that convert and takes responsibility for their numbers: CPA, CPL, ROI.",
        "I've been through the whole media buying path: account farmer, buyer's assistant, then a creative designer working inside live funnels for a long time. I know both sides of the table. Many of my creatives ended up in spy services, and I work with spy tools myself.",
        "My daily stack is After Effects, Photoshop, Premiere Pro and Figma, with AI tools for generation, lip-sync and voice replacement at every stage. I also vibe-code landing pages and prelanders.",
        "Examples from crypto, nutra and iGaming are available on request. Message me on Telegram: @bobombob.",
      ],
    },
  ],
};

const RESUME_LOCATION: Location = {
  id: 3,
  type: "resume",
  name: "Resume",
  icon: "/icons/file.svg",
  kind: "folder",
  children: [
    {
      id: 1,
      name: "Resume.pdf",
      icon: "/images/pdf.png",
      kind: "file",
      fileType: "pdf",
    },
  ],
};

const TRASH_LOCATION: Location = {
  id: 4,
  type: "trash",
  name: "Trash",
  icon: "/icons/trash.svg",
  kind: "folder",
  children: [],
};

export const locations: Record<string, Location> = {
  work: WORK_LOCATION,
  about: ABOUT_LOCATION,
  resume: RESUME_LOCATION,
  trash: TRASH_LOCATION,
};

export const INITIAL_Z_INDEX = 1000;

export const WINDOW_CONFIG: WindowConfig = {
  finder: { isOpen: false, zIndex: INITIAL_Z_INDEX, data: null },
  contact: { isOpen: false, zIndex: INITIAL_Z_INDEX, data: null },
  resume: { isOpen: false, zIndex: INITIAL_Z_INDEX, data: null },
  safari: { isOpen: false, zIndex: INITIAL_Z_INDEX, data: null },
  photos: { isOpen: false, zIndex: INITIAL_Z_INDEX, data: null },
  terminal: { isOpen: false, zIndex: INITIAL_Z_INDEX, data: null },
  txtfile: { isOpen: false, zIndex: INITIAL_Z_INDEX, data: null },
  imgfile: { isOpen: false, zIndex: INITIAL_Z_INDEX, data: null },
};
