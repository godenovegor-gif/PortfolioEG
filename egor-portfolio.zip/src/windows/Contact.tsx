import WindowWrapper from "@hoc/WindowWrapper";
import { socials } from "@constants/index";
import { WindowControls } from "@components/index";

const Contact = () => {
  return (
    <>
      <div id="window-header">
        <WindowControls target="contact" />
        <h2>Contact Me</h2>
      </div>

      <div className="p-5 space-y-5">
        <img
          src="/images/egor.png"
          alt="Egor Godenov"
          className="w-20 h-20 object-cover rounded-full"
        />

        <h3>Let's work together</h3>
        <p>Open to full-time roles and freelance projects in performance creatives.</p>
        <p>Examples from crypto, nutra and iGaming are available on request. Write me on Telegram: @bobombob</p>
        <p>egor.godenov@icloud.com</p>

        <ul>
          {socials.map(({ id, bg, link, icon, text }) => (
            <li key={id} style={{ backgroundColor: bg }}>
              <a
                href={link}
                target="_blank"
                rel="noopener noreferrer"
                title={text}
              >
                <img src={icon} alt={text} className="size-5" />
                <p>{text}</p>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
};

const ContactWindow = WindowWrapper(Contact, "contact");

export default ContactWindow;
