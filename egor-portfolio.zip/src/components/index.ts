export { default as Navbar } from "./Navbar";
export { default as Welcome } from "./Welcome";
export { default as Dock } from "./Dock";
export { default as Home } from "./Home";
export { default as WindowControls } from "./WindowControls";
